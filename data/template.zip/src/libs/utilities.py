import os
import time
import base64

import dill as pickle
import numpy as np

from IPython.display import clear_output
from qiskit import QuantumCircuit
from qiskit.algorithms.optimizers import COBYLA, L_BFGS_B
from qiskit.circuit import Parameter
from qiskit.circuit.library import RealAmplitudes, ZZFeatureMap
from qiskit.utils import algorithm_globals
from qiskit import qpy
from qiskit_machine_learning.algorithms.classifiers import NeuralNetworkClassifier, VQC
from qiskit_machine_learning.algorithms.regressors import NeuralNetworkRegressor, VQR
from qiskit_machine_learning.neural_networks import SamplerQNN, EstimatorQNN

algorithm_globals.random_seed = 42


def train(data, params):
    X_train = np.asarray(data["X_train"])
    y_train = np.asarray(data["y_train"])
    X_test = np.asarray(data["X_test"])
    y_test = np.asarray(data["y_test"])
    maxiter = params["maxiter"]
    reps = params["reps"]

    n_dims = X_train.shape[1]
    model = build_model(n_dims, maxiter, reps)
    model.fit(X_train, y_train)
    score_train = model.score(X_train, y_train)
    score_test = model.score(X_test, y_test)
    model = decode_model(model)

    return {"model": model,
            "score_train": score_train,
            "score_test": score_test}


def predict(data, params):
    x = np.asarray(data["x"])
    model = data["model"]

    model = encode_model(model)
    start = time.time()
    y = model.predict(x)
    stop = time.time()
    result = {"input": x,
              "output": y.tolist(),
              "inference_duration": stop - start}

    return result


def build_model(n_dims, maxiter=1, reps=1):
    feature_map = ZZFeatureMap(n_dims)
    ansatz = RealAmplitudes(n_dims, reps=reps)

    # construct variational quantum classifier
    model = VQC(
        feature_map=feature_map,
        ansatz=ansatz,
        loss="cross_entropy",
        optimizer=COBYLA(maxiter=maxiter),
    )

    return model


def decode_model(model_qiskit):
    model_as_bytes_unknown_encoding = pickle.dumps(model_qiskit)
    model_as_bytes_base64 = base64.b64encode(model_as_bytes_unknown_encoding)
    model_as_string_base64 = model_as_bytes_base64.decode('utf-8')
    return model_as_string_base64


def encode_model(model_as_string_base64):
    model_as_bytes_base64 = model_as_string_base64.encode('utf-8')
    model_as_bytes_unknown_encoding = base64.b64decode(model_as_bytes_base64)
    model_qiskit = pickle.loads(model_as_bytes_unknown_encoding)
    return model_qiskit
