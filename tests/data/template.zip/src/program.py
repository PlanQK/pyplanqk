"""
Template for implementing services running on the PlanQK platform
"""

import math
from typing import Dict, Any, Optional, Union

from loguru import logger

from .libs.return_objects import ResultResponse, ErrorResponse


def run(data: Optional[Dict[str, Any]] = None, params: Optional[Dict[str, Any]] = None) \
        -> Union[ResultResponse, ErrorResponse]:
    try:
        import json
        import numpy as np
        from .libs.utilities import train, predict

        print("PlanQK:Job:InterimResult:", json.dumps({"params": params}))
        print("PlanQK:Job:InterimResult:", json.dumps({"data": data}))

        mode = params["mode"]
        
        if mode == "train":
            print("PlanQK:Job:InterimResult:", json.dumps({"info": "Training started."}))
            result = train(data, params)
        elif mode == "predict":
            print("PlanQK:Job:InterimResult:", json.dumps({"info": "Prediction started"}))
            result = predict(data, params)
        else:
            return ErrorResponse(code="500", detail=f"Invalid mode={mode}.")
        
        logger.debug("Calculation successfully executed")
        
        return ResultResponse(result=result)
    except Exception as e:
        return ErrorResponse(code="500", detail=f"{type(e).__name__}: {e}")
